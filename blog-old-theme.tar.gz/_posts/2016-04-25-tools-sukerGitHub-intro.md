---
layout: post
title:  Suker GitHub repositories
category: private
description: suker github.com 에 구성한 repository list up
tags: development
---

<img src="/assets/images/github_icon.png" width="48" align="right"/>
<br>

### Repositories

---

#### [kchhero/docFile](https://github.com/kchhero/docFiles)
- krogoth_nexell_guide
- yocto_Jethro_general.md
- yocto_KrogothWithArtik7.md

---

#### [kchhero/sukerReference](https://github.com/kchhero/sukerReference)
- shell script reference code

---

#### [kchhero/suker_java_project](https://github.com/kchhero/suker_java_project)
- SWT_AndroSuker
- SWT_SukerEditor
- SWT_TraySuker

---

#### [kchhero/suker_clojure_project](https://github.com/kchhero/suker_clojure_project)
- suker clojure study 자료
- tools

---

#### [kchhero/suker_python_project](https://github.com/kchhero/suker_python_project)
- CodeJams sources
- CodeSamples   several files
- sukerAllRound
- sukerEasyDP
- sukerLotto
- sukerRDA
- sukerScripts -> python scripts 모음
- sukerStock -> 주식 show
- wxPython_layouts

---

#### [kchhero/suker_enviroment](https://github.com/kchhero/suker_enviroment)
- .bashrc
- .emacs .emacs.d ...

---

