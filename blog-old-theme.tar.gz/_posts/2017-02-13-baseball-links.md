---
layout: post
tags:
  - baseball
title: baseball
category: baseball
---
#### LINKS

1 [피칭통념](https://youtu.be/KBfH6-2JycM "피칭통념")

2 [피칭 훈련](https://youtu.be/SjP5THX4clk "피칭 훈련")

3 [브레이킹 볼](https://youtu.be/UdGBSUAegyg "브레이킹 볼")

4 [야구공 잡는 방법](https://youtu.be/c2OJm2xUI9I "야구공 잡는 방법")

5 [릴리스 포인트](https://youtu.be/NOIZBcGLDsg "릴리스 포인트")

6 [박찬호 선수의 공 던지는법과 종류](https://youtu.be/2Y1-DKXH1DU "박찬호 선수의 공 던지는법과 종류")
