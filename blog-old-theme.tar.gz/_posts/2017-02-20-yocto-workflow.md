---
title: workflow
layout: post
tags:
  - yocto
category: yocto
---
##### yocto workflow
![](https://github.com/kchhero/docFiles/blob/master/yocto_images/recipe-workflow.png?raw=true)

---

##### recipe sequence
![](https://github.com/kchhero/docFiles/blob/master/yocto_images/sequence.jpg?raw=true)