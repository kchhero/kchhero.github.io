---
layout: post
tags: tools
title: SukerEasyRamdumpParserRunner
category: Tools
description: 2013년 python 공부를 시작하면서 만들어봄.
---

- 2013년 python 공부를 시작하면서 만들어봄.

```shell?line_number=false
Language : Python 2.7
개발환경 : window7 32bit, Spyder 2.2.5
UI 제작 tool & Library : wxGlade, wx
packageing : Inno Script Studio
```
소스 및 실행파일은 회사 보안 정책상 upload가 안되어 못올림.

목적 ; dump file의 path와 vmlinux path를 설정하고 RUN 시키면 QCT ramdump parser를 실행함. cmd 창 띄워놓고 typing 하기 귀찮아서 만듦. 
![](/assets/ext_images/parserrunner.PNG)
