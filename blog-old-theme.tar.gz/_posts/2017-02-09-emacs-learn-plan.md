---
layout: post
tags: emacs
title: 'emacs learn'
category: Tools
description: emacs learnning scrap
---
[![](http://sachachua.com/blog/wp-content/uploads/2013/05/How-to-Learn-Emacs8.png)](http://sachachua.com/blog/series/a-visual-guide-to-emacs/)

<br>

![](https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTaEHyF5j3UMKPS2uZT3UmvxOTE0RartWo96x0jvkVJ5-q6HgZ5)