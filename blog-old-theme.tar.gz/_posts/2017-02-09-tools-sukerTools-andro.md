---
layout: post
tags: tools
title: Andro Suker 1.6.0
category: Tools
description: 2012년에 AdbUtility 라는 이름으로 처음 만들었던 개발 tool.
---

- 2012년에 AdbUtility 라는 이름으로 처음 만들었던 개발 tool.

틈날때마다 기능 추가 및 수정하여, AndroSuker 1.6.0 까지 version up 하였음.

```shell?line_number=false
Language : JAVA, Perl
개발환경 : window XP, window7 32bit, Eclipse
layout : UI tool kit으로 SWT를 사용함. (처음 개발할 당시에는 swing이었으나 UI가 마음에 들지않아 변경함)
배포tool : Launch4j
```
소스 및 실행파일은 회사 보안 정책상 upload가 안되어 못올림.

![](/assets/ext_images/andro1.png)
![](/assets/ext_images/andro2.png)
![](/assets/ext_images/andro3.png)
![](/assets/ext_images/andro4.png)
![](/assets/ext_images/andro5.png)