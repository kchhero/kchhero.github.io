---
category: private
description: 'suker bitbucket.com 에 구성한 repository list up'
layout: post
tags: development
title: 'Suker Bitbucket repositories'
---

<img src="/assets/images/bitbucket.png" width="48" align="right">
<br>

### Repositories

---

#### [meta-nexell](https://bitbucket.org/kchhero/meta-nexell)
- meta-nexell repository

---

#### [docker-opengrok](https://bitbucket.org/kchhero/docker-opengrok)
- opengrok docker image

---

#### [docker-jenkins](https://bitbucket.org/kchhero/docker-jenkins)
- jenkins docker image

---

#### [docker-fileserver](https://bitbucket.org/kchhero/docker-fileserver)
- apache snapshot/release server docker images, based linaro

---

#### [others](https://bitbucket.org/kchhero/others)
- Machine Learning data, LAVA-docker data, Private Documents

---
