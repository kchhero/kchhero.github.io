---
tags: about
layout: page
title: "About"
crawlertitle: "Why and how this blog was created"
permalink: /about/
summary: "About SUKER"
active: about
---

<img src="{{site.baseurl}}/assets/images/suker_about.jpg" alt="ㅋㅋ" style="width:640px;height:240px;" align="left"/>

<br><br><br><br><br><br><br><br><br><br><br>

<p fontsize="4"><b>Name : choonghyun Jeon</b></p>

<p fontsize="4"><b>Country : Korea</b></p>

<p fontsize="4"><b>WORK :</b></p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- 2004.12 ~ 2016.04  LG electronics, Mobile, SW engineer
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- 2016.04 ~          Nexell, SW engineer

<p fontsize="4">Recently working :<b> LAVA, docker, yocto</b></p>

<p fontsize="4"><b>Interested : functional language - clojure</b></p>

<p fontsize="4"><b>Available : C/C++, python, java</b></p>

<a style="color:blue" fontsize="3">Email : </a><a fontsize="2" href="mailto:{{ site.email }}">{{ site.email }} , <a href="mailto:suker@nexell.co.kr">suker@nexell.co.kr</a>

<p fontsize="4">Address Home : Suwon-si, Gyeonggi-do, Korea</p>

<p fontsize="4">Address Office : Seongnam-si, Gyeonggi-do, Korea</p>
