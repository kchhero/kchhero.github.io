#ifndef _RISCV_DEVICE_H
#define _RISCV_DEVICE_H


#endif
