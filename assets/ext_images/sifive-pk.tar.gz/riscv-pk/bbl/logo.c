#include <string.h>
#include "mtrap.h"

static const char logo[] =
"\r\n"
"                NEXELL, INC.\r\n"
"\r\n"
"oooooooooooooooooooooooooooooooooooooooooooo\r\n"
"oo   oooooooooooooo   o   oooooooooooooo   o\r\n"
"oo    ooooooooooooo   oo   oooooooooooo   oo\r\n"
"oo     oooooooooooo   ooo   oooooooooo   ooo\r\n"
"oo      ooooooooooo   oooo   oooooooo   oooo\r\n"
"oo   o   oooooooooo   ooooo   oooooo   ooooo\r\n"
"oo   oo   ooooooooo   oooooo   oooo   oooooo\r\n"
"oo   ooo   oooooooo   ooooooo   oo   ooooooo\r\n"
"oo   oooo   ooooooo   oooooooo      oooooooo\r\n"
"oo   ooooo   oooooo   ooooooooo    ooooooooo\r\n"
"oo   oooooo   ooooo   ooooooooo    ooooooooo\r\n"
"oo   ooooooo   oooo   oooooooo      oooooooo\r\n"
"oo   oooooooo   ooo   ooooooo   oo   ooooooo\r\n"
"oo   ooooooooo   oo   oooooo   oooo   oooooo\r\n"
"oo   oooooooooo   o   ooooo   oooooo   ooooo\r\n"
"oo   ooooooooooo      oooo   oooooooo   oooo\r\n"
"oo   oooooooooooo     ooo   oooooooooo   ooo\r\n"
"oo   ooooooooooooo    oo   oooooooooooo   oo\r\n"
"oo   oooooooooooooo   o   oooooooooooooo   o\r\n"
"oooooooooooooooooooooooooooooooooooooooooooo\r\n"
"\r\n"
"             Nexell RISC-V\r\n";

void print_logo()
{
  putstring(logo);
}
