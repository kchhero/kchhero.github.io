#ifndef _ASM_RISCV_LINKAGE_H
#define _ASM_RISCV_LINKAGE_H

#define __ALIGN		.balign 4
#define __ALIGN_STR	".balign 4"

#endif /* _ASM_RISCV_LINKAGE_H */
